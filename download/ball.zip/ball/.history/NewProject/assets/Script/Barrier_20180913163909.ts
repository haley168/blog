// Learn TypeScript:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html

const {ccclass, property} = cc._decorator;

@ccclass
export default class Barrier extends cc.Component {

    @property(cc.Label)
    lbScore:cc.Label = null;

    @property(Boolean)
    isAddBuffBall:boolean = false;

    score:number = 100;
    main:MainController;

    onLoad(){
        this.setScore(this.score);
    }

    start () {
        if(this.lbScore){
            this.lbScore.node.rotation = -this.node.rotation;
        }
    }
    setScore(score:number){
        if(this.lbScore){
            this.score = score;
            this.lbScore.string = this.score.toString()
        }
    }

    onBeginContact(contact: cc.PhysicsContact, selfCollider: cc.PhysicsCollider, otherCollider: cc.PhysicsCollider){
       if(this.isAddBuffBall){
           this.main.addBall(this.node.position);
           this.main.removeBarrier(this);
           return;

           //把自己删除，同事产生新的球
       }else{
           this.setScore(this.score-1);
       }
    }
    onEndContact(contact: cc.PhysicsContact, selfCollider: cc.PhysicsCollider, otherCollider: cc.PhysicsCollider){
        console.log('222')

    }
    onPreSolve(contact: cc.PhysicsContact, selfCollider: cc.PhysicsCollider, otherCollider: cc.PhysicsCollider){
        console.log('33')

    }
    onPostSolve(contact: cc.PhysicsContact, selfCollider: cc.PhysicsCollider, otherCollider: cc.PhysicsCollider){
        console.log('444')

    }
    // update (dt) {}
}
