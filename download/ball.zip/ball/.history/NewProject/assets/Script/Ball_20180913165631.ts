// Learn TypeScript:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html

const {ccclass, property} = cc._decorator;

@ccclass
export default class NewClass extends cc.Component {

    isTouchGround:boolean = false;
    @property(cc.RigidBody)
    rigidBody:cc.RigidBody = null;

    onLoad(){
        this.rigidBody = this.getComponent(cc.RigidBody);
    }

    update(){
        if(this.isTouchGround){
            this.rigidBody.active = false;
            this.rigidBody.linearVelocity = cc.Vec2.ZERO;

            let pathPos:cc.Vec2[] = [];
            pathPos.push(this.node.position);
            pathPos.push(cc.v2(217,-233));
            pathPos.push(cc.v2(215,375));
            pathPos.push(cc.v2(35,347));

            this.node.runAction(cc.sequence(
                cc.cardinalSplineTo(2,pathPos,1),
                cc.callFunc(function () {
                    this.rigidBody.active = true;
                }.bind(this))
            ))
            this.isTouchGround = false;
        }
    }
    onBeginContact(contact: cc.PhysicsContact, selfCollider: cc.PhysicsCollider, otherCollider: cc.PhysicsCollider){
        if(otherCollider.node.name == "ground"){
            this.isTouchGround = true;
        }
    }
}
