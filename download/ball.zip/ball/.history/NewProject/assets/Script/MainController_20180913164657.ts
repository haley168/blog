
import Barrier from "./Barrier";
import Ball from "./Ball";
import callFunc = cc.callFunc;


const {ccclass, property} = cc._decorator;

@ccclass
export default class NewClass extends cc.Component {
    @property(cc.Prefab)
    prefabBall:cc.Prefab;

    @property([cc.Prefab])
    prefabBarries:cc.Prefab[] = [];

    @property([Ball])
    balls:Ball[] = [];

    barriers:Barrier[] = [];

    onLoad(){
        this.addBarriers()
        this.node.on(cc.Node.EventType.TOUCH_START,this.onTouchStart,this);
    }
    addBall(pos:cc.Vec2){
        let ball = cc.instantiate(this.prefabBall).getComponent<Ball>(Ball);
        ball.node.parent = this.node;
        this.node.position = pos;
        this.balls.push(ball);
    }

    onTouchStart(touch:cc.Event.EventTouch){
        let touchPos = this.node.convertTouchToNodeSpaceAR(touch.touch)       ;
        console.log(JSON.stringify(touchPos));
        this.shootBall(this.balls[0],cc.pSub(touchPos,cc.v2(0,243)))
    }
    shootBall(ball:Ball,dir:cc.Vec2){
        ball.rigidBody.active = false;
        let poses:cc.Vec2[]=[];
        poses.push(ball.node.position);
        poses.push(cc.v2(0,243));

        ball.node.runAction(cc.sequence(
            cc.cardinalSplineTo(0.8,poses,0.5),
            callFunc(function () {
                ball.rigidBody.active = true;
                ball.rigidBody.linearVelocity = cc.pMult(dir,3);
            })
        ))
    }

    addBarriers(){
        let startPosX = -192;
        let endPosX = 191;
        let currentPosX= startPosX +this.getRandomSpace();
        while(currentPosX<endPosX){
            let barrier = cc.instantiate(this.prefabBarries[Math.floor(Math.random()*this.prefabBarries.length)]).getComponent<Barrier>(Barrier)
            barrier.node.parent = this.node;
            barrier.node.position = cc.v2(currentPosX,-200);
            barrier.main = this;
            currentPosX+=this.getRandomSpace();
            this.barriers.push(barrier);
            // this.addBall(this.barriers[0].node.position)
        }


    }
    removeBarrier(barrier:Barrier){
        let idx = this.barriers.indexOf(barrier);
        if(idx!=-1){
            barrier.node.removeFromParent(false)
            this.barriers.splice(idx,1);
        }

    }
    getRandomSpace():number{
        return 100+Math.random()*100;
    }

}
