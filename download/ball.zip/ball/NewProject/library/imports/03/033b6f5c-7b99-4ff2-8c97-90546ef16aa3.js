"use strict";
cc._RF.push(module, '033b69ce5lP8oyXkFRu8Wqj', 'MainController');
// Script/MainController.ts

Object.defineProperty(exports, "__esModule", { value: true });
var Barrier_1 = require("./Barrier");
var Ball_1 = require("./Ball");
var callFunc = cc.callFunc;
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var NewClass = /** @class */ (function (_super) {
    __extends(NewClass, _super);
    function NewClass() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.prefabBarries = [];
        _this.balls = [];
        _this.barriers = [];
        return _this;
    }
    NewClass.prototype.onLoad = function () {
        this.addBarriers();
        this.node.on(cc.Node.EventType.TOUCH_START, this.onTouchStart, this);
    };
    NewClass.prototype.addBall = function (pos) {
        var ball = cc.instantiate(this.prefabBall).getComponent(Ball_1.default);
        ball.node.parent = this.node;
        this.node.position = pos;
        this.balls.push(ball);
    };
    NewClass.prototype.onTouchStart = function (touch) {
        var touchPos = this.node.convertTouchToNodeSpaceAR(touch.touch);
        this.shootBall(this.balls[0], cc.pSub(touchPos, cc.v2(0, 243)));
    };
    NewClass.prototype.shootBall = function (ball, dir) {
        ball.rigidBody.active = false;
        var poses = [];
        poses.push(ball.node.position);
        poses.push(cc.v2(0, 243));
        ball.node.runAction(cc.sequence(cc.cardinalSplineTo(0.8, poses, 0.5), callFunc(function () {
            ball.rigidBody.active = true;
            ball.rigidBody.linearVelocity = cc.pMult(dir, 3);
        })));
    };
    NewClass.prototype.addBarriers = function () {
        var startPosX = -192;
        var endPosX = 191;
        var currentPosX = startPosX + this.getRandomSpace();
        while (currentPosX < endPosX) {
            var barrier = cc.instantiate(this.prefabBarries[Math.floor(Math.random() * this.prefabBarries.length)]).getComponent(Barrier_1.default);
            barrier.node.parent = this.node;
            barrier.node.position = cc.v2(currentPosX, -200);
            barrier.main = this;
            currentPosX += this.getRandomSpace();
            this.barriers.push(barrier);
        }
    };
    NewClass.prototype.removeBarrier = function (barrier) {
        var idx = this.barriers.indexOf(barrier);
        if (idx != -1) {
            barrier.node.removeFromParent(false);
            this.barriers.splice(idx, 1);
        }
    };
    NewClass.prototype.getRandomSpace = function () {
        return 100 + Math.random() * 100;
    };
    __decorate([
        property(cc.Prefab)
    ], NewClass.prototype, "prefabBall", void 0);
    __decorate([
        property([cc.Prefab])
    ], NewClass.prototype, "prefabBarries", void 0);
    __decorate([
        property([Ball_1.default])
    ], NewClass.prototype, "balls", void 0);
    NewClass = __decorate([
        ccclass
    ], NewClass);
    return NewClass;
}(cc.Component));
exports.default = NewClass;

cc._RF.pop();