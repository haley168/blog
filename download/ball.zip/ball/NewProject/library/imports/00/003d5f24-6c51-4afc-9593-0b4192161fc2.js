"use strict";
cc._RF.push(module, '003d58kbFFK/JWTC0GSFh/C', 'Barrier');
// Script/Barrier.ts

// Learn TypeScript:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Barrier = /** @class */ (function (_super) {
    __extends(Barrier, _super);
    function Barrier() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.lbScore = null;
        _this.isAddBuffBall = false;
        _this.score = 100;
        return _this;
    }
    Barrier.prototype.onLoad = function () {
        this.setScore(this.score);
    };
    Barrier.prototype.start = function () {
        if (this.lbScore) {
            this.lbScore.node.rotation = -this.node.rotation;
        }
    };
    Barrier.prototype.setScore = function (score) {
        if (this.lbScore) {
            this.score = score;
            this.lbScore.string = this.score.toString();
        }
    };
    Barrier.prototype.onBeginContact = function (contact, selfCollider, otherCollider) {
        if (this.isAddBuffBall) {
            this.main.addBall(this.node.position);
            this.main.removeBarrier(this);
            //把自己删除，同事产生新的球
        }
        else {
            this.setScore(this.score - 1);
        }
    };
    __decorate([
        property(cc.Label)
    ], Barrier.prototype, "lbScore", void 0);
    __decorate([
        property(Boolean)
    ], Barrier.prototype, "isAddBuffBall", void 0);
    Barrier = __decorate([
        ccclass
    ], Barrier);
    return Barrier;
}(cc.Component));
exports.default = Barrier;

cc._RF.pop();