(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/Ball.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'ba3d5L43qlMLLAQYml90Y+d', 'Ball', __filename);
// Script/Ball.ts

// Learn TypeScript:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var NewClass = /** @class */ (function (_super) {
    __extends(NewClass, _super);
    function NewClass() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.isTouchGround = false;
        _this.rigidBody = null;
        return _this;
        // update (dt) {}
    }
    NewClass.prototype.onLoad = function () {
        this.rigidBody = this.getComponent(cc.RigidBody);
    };
    NewClass.prototype.update = function () {
        if (this.isTouchGround) {
            this.rigidBody.active = false;
            this.rigidBody.linearVelocity = cc.Vec2.ZERO;
            var pathPos = [];
            pathPos.push(this.node.position);
            pathPos.push(cc.v2(217, -233));
            pathPos.push(cc.v2(215, 375));
            pathPos.push(cc.v2(35, 347));
            this.node.runAction(cc.sequence(cc.cardinalSplineTo(2, pathPos, 1), cc.callFunc(function () {
                this.rigidBody.active = true;
            }.bind(this))));
            this.isTouchGround = false;
        }
    };
    NewClass.prototype.onBeginContact = function (contact, selfCollider, otherCollider) {
        if (otherCollider.node.name == "ground") {
            this.isTouchGround = true;
        }
    };
    NewClass.prototype.onEndContact = function (contact, selfCollider, otherCollider) {
        console.log('222');
    };
    NewClass.prototype.onPreSolve = function (contact, selfCollider, otherCollider) {
        console.log('33');
    };
    NewClass.prototype.onPostSolve = function (contact, selfCollider, otherCollider) {
        console.log('444');
    };
    __decorate([
        property(cc.RigidBody)
    ], NewClass.prototype, "rigidBody", void 0);
    NewClass = __decorate([
        ccclass
    ], NewClass);
    return NewClass;
}(cc.Component));
exports.default = NewClass;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Ball.js.map
        